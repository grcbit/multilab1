[1.0.1]
[Fix]: Fixed delivery order quantity issue

==========================================

[1.0.0]
[Add]: Added 'Credit Limit' module

