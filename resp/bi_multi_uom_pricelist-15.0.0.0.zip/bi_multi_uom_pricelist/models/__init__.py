# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.

from . import product_template
from . import product_pricelist_inherit
from . import sale_inherit
from . import account_invoice_inherit

